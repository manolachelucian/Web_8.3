const express = require('express');
const bcrypt = require('bcrypt');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;

const app = express();

// Passport konfigurace
passport.use(new LocalStrategy(
    function(username, password, done) {
        // Zkontrolujte uživatele v databázi
    const query = `SELECT * FROM Users WHERE username = '${username}';`;
    // Spusťte dotaz na databázi
    // Předpokládejme, že "db" je vaše databázové připojení a "user" je výsledek dotazu
    db.query(query, function(err, user) {
      if (err) { return done(err); }
      if (!user) {
        return done(null, false, { message: 'Neznámé uživatelské jméno.' });
      }

      // Porovnejte zadané heslo s uloženým hashem
      bcrypt.compare(password, user.password, function(err, isMatch) {
        if (err) { return done(err); }
        if (!isMatch) {
          return done(null, false, { message: 'Nesprávné heslo.' });
        }
        return done(null, user);
      });
    });



    
    }));

// Endpoint pro přihlášení
app.post('/login', passport.authenticate('local', { successRedirect: 'menu.html', failureRedirect: '/login' }));

// Endpoint pro registraci
app.post('/register', (req, res) => {
    const username = req.body.username;
    const password = req.body.password;
  
    // Hash hesla
    bcrypt.hash(password, 10, function(err, hash) {
        const query = `INSERT INTO Users (username, pass) VALUES ('${username}', '${hash}');`;
    });
  });